make test03

./bin/test
